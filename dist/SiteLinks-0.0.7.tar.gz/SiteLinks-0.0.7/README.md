# SiteLinks
This is a small project intended to allow scraping all the the links off a website, mostly useful for CTFs.
<!--
## Installaion
```shell script
$ python3 -m pip install 
```
-->
## Usage:

To use the script simply run:
```
$ python -m SiteLinks [--depth] [-s] [-o] hostname
```
#### Flags:
+ -s - Include search status (Significantly longer run)
+ -o - Include outside link